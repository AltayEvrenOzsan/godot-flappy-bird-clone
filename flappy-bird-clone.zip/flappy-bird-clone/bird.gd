class_name Bird
extends CharacterBody2D

signal died

const GRAVITY := 500.0
const FLAP_VELOCITY := -150.0

@export var floor_y := 216.0

var active := false
var alive := true
var _bob: Tween

@onready var sprite: Sprite2D = $Sprite2D
@onready var anim: AnimationPlayer = $Sprite2D/AnimationPlayer


func _ready() -> void:
	anim.play("flap")
	_bob = create_tween().set_loops().set_trans(Tween.TRANS_SINE)
	_bob.tween_property(sprite, "position:y", 2.0, 0.4)
	_bob.tween_property(sprite, "position:y", -2.0, 0.4)


func start() -> void:
	_bob.kill()
	sprite.position.y = 0.0
	active = true


func flap() -> void:
	if alive:
		velocity.y = FLAP_VELOCITY


func die() -> void:
	if not alive:
		return
	alive = false
	anim.pause()
	died.emit()


func _physics_process(delta: float) -> void:
	if not active:
		return

	velocity.y += GRAVITY * delta
	move_and_slide()

	rotation = clampf(velocity.y / 215.0, -0.5, 1.2) if alive else 1.4

	if position.y <= 0.0:
		die()
	if position.y >= floor_y:
		position.y = floor_y
		die()
		set_physics_process(false)
