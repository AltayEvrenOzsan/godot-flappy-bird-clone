extends Node2D

const SPEED := 60.0
const SCREEN_W := 144.0

var _tile_w := 0.0
var _offset := 0.0

@onready var sprite: Sprite2D = $Sprite2D


func _ready() -> void:
	add_to_group("scrolling")
	_tile_w = sprite.texture.get_width()

	sprite.centered = false
	sprite.region_enabled = false

	var count := ceili(SCREEN_W / _tile_w) + 2
	for i in range(1, count):
		var tile: Sprite2D = sprite.duplicate()
		tile.position.x = i * _tile_w
		add_child(tile)


func _physics_process(delta: float) -> void:
	_offset += SPEED * delta
	if _offset >= _tile_w:
		_offset -= _tile_w
		position.x = -_offset
		reset_physics_interpolation() # prevents a smear when the position jumps back
	else:
		position.x = -_offset
