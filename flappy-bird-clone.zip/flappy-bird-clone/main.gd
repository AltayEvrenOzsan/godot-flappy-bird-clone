extends Node2D

enum State { WAITING, PLAYING, DEAD }

const PIPE_SCENE := preload("res://pipe_pair.tscn")
const SCREEN := Vector2(144.0, 256.0)
const GROUND_H := 32.0
const GAP_MARGIN := 30.0 # min distance of gap edge from ceiling/ground

var state := State.WAITING
var score := 0
var pipes: Node2D # created in code

@onready var bird: Bird = $Bird
@onready var spawn_timer: Timer = $SpawnTimer
@onready var score_label: Label = $UI/ScoreLabel
@onready var message_label: Label = $UI/MessageLabel


func _ready() -> void:
	randomize()

	pipes = Node2D.new()
	pipes.name = "Pipes"
	add_child(pipes)
	move_child(pipes, bird.get_index())

	score_label.text = "0"
	bird.died.connect(_on_bird_died)
	spawn_timer.timeout.connect(_spawn_pipe)


func _unhandled_input(event: InputEvent) -> void:
	if not event.is_action_pressed("flap"):
		return

	match state:
		State.WAITING:
			state = State.PLAYING
			message_label.text = ""
			bird.start()
			bird.flap()
			_spawn_pipe()
			spawn_timer.start()
		State.PLAYING:
			bird.flap()
		State.DEAD:
			get_tree().reload_current_scene()


func _spawn_pipe() -> void:
	var half_gap := PipePair.GAP_SIZE / 2.0
	var min_y := GAP_MARGIN + half_gap
	var max_y := SCREEN.y - GROUND_H - GAP_MARGIN - half_gap

	var pipe: PipePair = PIPE_SCENE.instantiate()
	pipe.position = Vector2(SCREEN.x + 30.0, roundf(randf_range(min_y, max_y)))
	pipe.scored.connect(_on_scored)
	pipe.hit.connect(bird.die)
	pipes.add_child(pipe)


func _on_scored() -> void:
	score += 1
	score_label.text = str(score)


func _on_bird_died() -> void:
	state = State.DEAD
	spawn_timer.stop()
	get_tree().call_group("scrolling", "set_physics_process", false)
	message_label.text = "Game Over\nTap to restart"
