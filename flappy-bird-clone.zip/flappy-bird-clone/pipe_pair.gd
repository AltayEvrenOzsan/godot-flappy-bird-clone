class_name PipePair
extends Node2D

signal hit
signal scored

const PIPE_LENGTH := 170.0 
const CAP_HEIGHT := 19.0
const SPEED := 60.0
const GAP_SIZE := 58.0

var _scored := false

@onready var top_pipe: Area2D = $TopPipe
@onready var bottom_pipe: Area2D = $BottomPipe
@onready var score_zone: Area2D = $ScoreZone
@export var rod_texture: Texture2D

func _ready() -> void:
	add_to_group("scrolling")
	_build_pipe(top_pipe, true)
	_build_pipe(bottom_pipe, false)

	var zone_shape := RectangleShape2D.new()
	zone_shape.size = Vector2(2.0, GAP_SIZE)
	score_zone.get_node("CollisionShape2D").shape = zone_shape

	top_pipe.body_entered.connect(_on_pipe_body_entered)
	bottom_pipe.body_entered.connect(_on_pipe_body_entered)
	score_zone.body_entered.connect(_on_zone_body_entered)


func _build_pipe(pipe: Area2D, is_top: bool) -> void:
	var cap: Sprite2D = pipe.get_node("Sprite2D")
	var collision: CollisionShape2D = pipe.get_node("CollisionShape2D")
	var tex: Texture2D = cap.texture
	var w := tex.get_width()

	# Cap: the top slice of the pipe texture
	cap.centered = false
	cap.region_enabled = true
	cap.region_rect = Rect2(0, 0, w, CAP_HEIGHT)
	cap.flip_v = is_top

	# Rod: stack copies of rod_texture, running away from the cap
	var rod_w := rod_texture.get_width()
	var rod_h := rod_texture.get_height()
	var count := ceili((PIPE_LENGTH - CAP_HEIGHT) / rod_h)
	for i in count:
		var rod := Sprite2D.new()
		rod.texture = rod_texture
		rod.centered = false
		if is_top:
			rod.position = Vector2(-rod_w / 2.0, -CAP_HEIGHT - (i + 1) * rod_h)
		else:
			rod.position = Vector2(-rod_w / 2.0, CAP_HEIGHT + i * rod_h)
		pipe.add_child(rod)
		pipe.move_child(rod, 0) # draw behind the cap

	var shape := RectangleShape2D.new()
	shape.size = Vector2(w, PIPE_LENGTH)
	collision.shape = shape

	if is_top:
		pipe.position = Vector2(0.0, -GAP_SIZE / 2.0)
		cap.position = Vector2(-w / 2.0, -CAP_HEIGHT)
		collision.position = Vector2(0.0, -PIPE_LENGTH / 2.0)
	else:
		pipe.position = Vector2(0.0, GAP_SIZE / 2.0)
		cap.position = Vector2(-w / 2.0, 0.0)
		collision.position = Vector2(0.0, PIPE_LENGTH / 2.0)


func _physics_process(delta: float) -> void:
	position.x -= SPEED * delta
	if position.x < -40.0:
		queue_free()


func _on_pipe_body_entered(body: Node2D) -> void:
	if body is Bird:
		hit.emit()


func _on_zone_body_entered(body: Node2D) -> void:
	if body is Bird and not _scored:
		_scored = true
		scored.emit()
